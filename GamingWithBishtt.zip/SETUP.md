# GamingWithBishtt Bot — Setup Guide
## By Popkinn_Editz

---

## 1. Required: Add your Bot Token

Open `.env` and replace `PASTE_YOUR_BOT_TOKEN_HERE` with your actual bot token from the Discord Developer Portal.  
Everything else is already filled in (Client ID, Owner ID, prefix, etc).

---

## 2. Install Dependencies

Run this **once** on your host (in the bot's folder):
```
npm install
```

---

## 3. Start the Bot

```
npm start
```
or directly:
```
node src/app.js
```

---

## 4. Data Storage — globaldata.json

All economy balances, server configs, giveaways, tickets, levels, and everything else are **automatically saved** to:

```
data/globaldata.json
```

This file is created automatically when the bot starts for the first time.  
**Restarting the bot does NOT wipe any data** — everything loads back from this file.

You can view or even edit this file directly in your hosting file manager if needed.

> **Tip:** Back up `data/globaldata.json` occasionally from your file manager. That single file contains all your bot's data.

---

## 5. PostgreSQL (Optional)

PostgreSQL is a more powerful external database. **You do not need it** — the bot works perfectly with `globaldata.json`.

If your host provides PostgreSQL and you want to use it, fill in the `POSTGRES_*` values in `.env`. The bot will automatically use it and skip the JSON file.

---

## 6. Prefix Commands (default: `!`)

| Command | What it does |
|---|---|
| `!balance [@user]` | Check BishttBucks wallet & bank |
| `!daily` | Claim 500 BB daily reward |
| `!weekly` | Claim 5,000 BB weekly reward |
| `!work` | Work for 100–500 BB (30 min cooldown) |
| `!flip <amt> <heads/tails>` | Coin flip — double or nothing |
| `!slots <amt>` | Spin the slot machine |
| `!deposit <amt\|all>` | Deposit cash to bank |
| `!withdraw <amt\|all>` | Withdraw from bank |
| `!pay @user <amt>` | Pay another user |
| `!rob @user` | Try to rob someone |
| `!beg` | Beg for BishttBucks |
| `!profile [@user]` | View full economy profile |
| `!play <song>` | Play music in voice channel |
| `!skip` | Skip current track |
| `!stop` | Stop music & disconnect |
| `!queue` | View music queue |
| `!help` | Full command list in Discord |

**All commands also work as slash commands** — type `/` in Discord to see them all.

---

## 7. Currency: BishttBucks (BB)

- Symbol: **BB**
- Everyone starts with **100 BB**
- Daily: **500 BB** · Weekly: **5,000 BB** · Work: **100–500 BB**

---

## 8. Bot Invite Link

```
https://discord.com/oauth2/authorize?client_id=1414166108939751434&permissions=8&scope=bot%20applications.commands
```

---

## 9. Music

Pre-configured with 3 public Lavalink nodes. If music doesn't work, type `/refresh-lavalink` in Discord to reconnect.

---

**Bot: GamingWithBishtt | Owner: Popkinn_Editz**
