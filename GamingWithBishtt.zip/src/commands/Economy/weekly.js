import { SlashCommandBuilder } from 'discord.js';
import { successEmbed } from '../../utils/embeds.js';
import { getEconomyData, setEconomyData } from '../../utils/economy.js';
import { withErrorHandling, createError, ErrorTypes } from '../../utils/errorHandler.js';
import { formatDuration } from '../../utils/helpers.js';
import { InteractionHelper } from '../../utils/interactionHelper.js';

const WEEKLY_COOLDOWN = 7 * 24 * 60 * 60 * 1000;
const WEEKLY_AMOUNT = 5000;

export default {
    data: new SlashCommandBuilder()
        .setName('weekly')
        .setDescription('Claim your weekly BishttBucks bonus (5,000 BB every 7 days!)'),

    execute: withErrorHandling(async (interaction, config, client) => {
        const deferred = await InteractionHelper.safeDefer(interaction);
        if (!deferred) return;

        const userId = interaction.user.id;
        const guildId = interaction.guildId;
        const now = Date.now();

        const userData = await getEconomyData(client, guildId, userId);
        if (!userData) throw createError('DB error', ErrorTypes.DATABASE, 'Failed to load your data.');

        const lastWeekly = userData.lastWeekly || 0;
        if (now < lastWeekly + WEEKLY_COOLDOWN) {
            const remaining = lastWeekly + WEEKLY_COOLDOWN - now;
            throw createError('Cooldown', ErrorTypes.RATE_LIMIT,
                `You already claimed your weekly! Come back in **${formatDuration(remaining)}**.`);
        }

        userData.wallet = (userData.wallet || 0) + WEEKLY_AMOUNT;
        userData.lastWeekly = now;
        await setEconomyData(client, guildId, userId, userData);

        const embed = successEmbed(`You claimed your weekly **BB ${WEEKLY_AMOUNT.toLocaleString()}**! 🎉`, '📅 Weekly Reward!')
            .addFields(
                { name: '💰 Wallet', value: `BB ${userData.wallet.toLocaleString()}`, inline: true },
                { name: '⏰ Next Weekly', value: `<t:${Math.floor((now + WEEKLY_COOLDOWN) / 1000)}:R>`, inline: true }
            );

        await InteractionHelper.safeEditReply(interaction, { embeds: [embed] });
    }, { command: 'weekly' })
};
