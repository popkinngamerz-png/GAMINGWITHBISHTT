import { SlashCommandBuilder } from 'discord.js';
import { createEmbed } from '../../utils/embeds.js';
import { getEconomyData, getMaxBankCapacity } from '../../utils/economy.js';
import { withErrorHandling, createError, ErrorTypes } from '../../utils/errorHandler.js';
import { InteractionHelper } from '../../utils/interactionHelper.js';

export default {
    data: new SlashCommandBuilder()
        .setName('profile')
        .setDescription('View your full GamingWithBishtt economy profile')
        .addUserOption(o => o.setName('user').setDescription('User to check').setRequired(false)),

    execute: withErrorHandling(async (interaction, config, client) => {
        const deferred = await InteractionHelper.safeDefer(interaction);
        if (!deferred) return;

        const target = interaction.options.getUser('user') || interaction.user;
        const guildId = interaction.guildId;

        if (target.bot) throw createError('bot', ErrorTypes.VALIDATION, 'Bots do not have profiles.');

        const userData = await getEconomyData(client, guildId, target.id);
        if (!userData) throw createError('DB', ErrorTypes.DATABASE, 'Could not load profile data.');

        const wallet = userData.wallet || 0;
        const bank = userData.bank || 0;
        const maxBank = getMaxBankCapacity(userData);
        const total = wallet + bank;
        const level = userData.level || 1;
        const xp = userData.xp || 0;
        const streak = userData.dailyStreak || 0;

        const inventorySize = Object.values(userData.inventory || {}).reduce((a, b) => a + b, 0);

        const embed = createEmbed({
            title: `🎮 ${target.username}'s Profile`,
            color: 'primary',
            thumbnail: target.displayAvatarURL()
        })
        .addFields(
            { name: '💵 Wallet', value: `BB ${wallet.toLocaleString()}`, inline: true },
            { name: '🏦 Bank', value: `BB ${bank.toLocaleString()} / BB ${maxBank.toLocaleString()}`, inline: true },
            { name: '💎 Net Worth', value: `BB ${total.toLocaleString()}`, inline: true },
            { name: '⭐ Level', value: `${level}`, inline: true },
            { name: '✨ XP', value: `${xp.toLocaleString()}`, inline: true },
            { name: '🔥 Daily Streak', value: `${streak} days`, inline: true },
            { name: '🎒 Items Owned', value: `${inventorySize}`, inline: true }
        )
        .setFooter({ text: `GamingWithBishtt Economy • ${target.tag}` });

        await InteractionHelper.safeEditReply(interaction, { embeds: [embed] });
    }, { command: 'profile' })
};
