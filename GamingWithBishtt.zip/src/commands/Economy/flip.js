import { SlashCommandBuilder } from 'discord.js';
import { successEmbed, errorEmbed } from '../../utils/embeds.js';
import { getEconomyData, setEconomyData } from '../../utils/economy.js';
import { withErrorHandling, createError, ErrorTypes } from '../../utils/errorHandler.js';
import { InteractionHelper } from '../../utils/interactionHelper.js';

const FLIP_COOLDOWN = 30 * 1000; // 30 seconds

export default {
    data: new SlashCommandBuilder()
        .setName('flip')
        .setDescription('Flip a coin — double your bet or lose it all!')
        .addIntegerOption(o => o.setName('amount').setDescription('Amount of BB to bet').setRequired(true).setMinValue(1))
        .addStringOption(o => o.setName('choice').setDescription('heads or tails').setRequired(true)
            .addChoices({ name: 'Heads', value: 'heads' }, { name: 'Tails', value: 'tails' })),

    execute: withErrorHandling(async (interaction, config, client) => {
        const deferred = await InteractionHelper.safeDefer(interaction);
        if (!deferred) return;

        const userId = interaction.user.id;
        const guildId = interaction.guildId;
        const amount = interaction.options.getInteger('amount');
        const choice = interaction.options.getString('choice');
        const now = Date.now();

        const userData = await getEconomyData(client, guildId, userId);
        if (!userData) throw createError('DB error', ErrorTypes.DATABASE, 'Failed to load your data.');

        const lastFlip = userData.lastFlip || 0;
        if (now < lastFlip + FLIP_COOLDOWN) {
            const wait = Math.ceil((lastFlip + FLIP_COOLDOWN - now) / 1000);
            throw createError('Cooldown', ErrorTypes.RATE_LIMIT, `Wait **${wait}s** before flipping again.`);
        }

        if (userData.wallet < amount)
            throw createError('broke', ErrorTypes.VALIDATION, `You only have **BB ${userData.wallet.toLocaleString()}** in your wallet.`);

        const result = Math.random() < 0.5 ? 'heads' : 'tails';
        const won = result === choice;
        const emoji = result === 'heads' ? '🪙' : '🌑';

        if (won) {
            userData.wallet += amount;
        } else {
            userData.wallet -= amount;
        }
        userData.lastFlip = now;
        await setEconomyData(client, guildId, userId, userData);

        const embed = won
            ? successEmbed(`${emoji} **${result.toUpperCase()}** — You won **BB ${amount.toLocaleString()}**! 🎉`, '🪙 Coin Flip — WIN')
            : errorEmbed(`${emoji} **${result.toUpperCase()}** — You lost **BB ${amount.toLocaleString()}**!`)
                .setTitle('🪙 Coin Flip — LOSS');

        embed.addFields({ name: '💰 Wallet', value: `BB ${userData.wallet.toLocaleString()}`, inline: true });
        await InteractionHelper.safeEditReply(interaction, { embeds: [embed] });
    }, { command: 'flip' })
};
