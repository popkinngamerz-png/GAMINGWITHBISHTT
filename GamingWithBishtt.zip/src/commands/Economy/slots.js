import { SlashCommandBuilder } from 'discord.js';
import { createEmbed, errorEmbed } from '../../utils/embeds.js';
import { getEconomyData, setEconomyData } from '../../utils/economy.js';
import { withErrorHandling, createError, ErrorTypes } from '../../utils/errorHandler.js';
import { InteractionHelper } from '../../utils/interactionHelper.js';

const SLOTS_COOLDOWN = 60 * 1000;
const SYMBOLS = ['🍒', '🍋', '🍊', '🍇', '⭐', '💎', '7️⃣'];
const PAYOUTS = { '7️⃣': 10, '💎': 7, '⭐': 5, '🍇': 4, '🍊': 3, '🍋': 2, '🍒': 1.5 };

function spin() {
    const weights = [20, 18, 15, 12, 10, 5, 2]; // lower = rarer
    const total = weights.reduce((a, b) => a + b, 0);
    let rand = Math.random() * total;
    for (let i = 0; i < SYMBOLS.length; i++) {
        rand -= weights[i];
        if (rand <= 0) return SYMBOLS[i];
    }
    return SYMBOLS[0];
}

export default {
    data: new SlashCommandBuilder()
        .setName('slots')
        .setDescription('Spin the slot machine for big BB wins!')
        .addIntegerOption(o => o.setName('amount').setDescription('Amount of BB to bet').setRequired(true).setMinValue(1)),

    execute: withErrorHandling(async (interaction, config, client) => {
        const deferred = await InteractionHelper.safeDefer(interaction);
        if (!deferred) return;

        const userId = interaction.user.id;
        const guildId = interaction.guildId;
        const amount = interaction.options.getInteger('amount');
        const now = Date.now();

        const userData = await getEconomyData(client, guildId, userId);
        if (!userData) throw createError('DB error', ErrorTypes.DATABASE, 'Failed to load your data.');

        const lastSlots = userData.lastSlots || 0;
        if (now < lastSlots + SLOTS_COOLDOWN) {
            const wait = Math.ceil((lastSlots + SLOTS_COOLDOWN - now) / 1000);
            throw createError('Cooldown', ErrorTypes.RATE_LIMIT, `Wait **${wait}s** before spinning again.`);
        }

        if (userData.wallet < amount)
            throw createError('broke', ErrorTypes.VALIDATION, `You only have **BB ${userData.wallet.toLocaleString()}** in your wallet.`);

        const s1 = spin(), s2 = spin(), s3 = spin();
        const reels = `[ ${s1} | ${s2} | ${s3} ]`;

        let multiplier = 0;
        let resultMsg = '';

        if (s1 === s2 && s2 === s3) {
            multiplier = PAYOUTS[s1] || 2;
            resultMsg = `🎰 **JACKPOT!** Triple ${s1}! You won **${multiplier}x** your bet!`;
        } else if (s1 === s2 || s2 === s3 || s1 === s3) {
            multiplier = 1.5;
            resultMsg = `✨ **Two of a kind!** You won **1.5x** your bet!`;
        } else {
            resultMsg = `💸 No match. Better luck next time!`;
        }

        const winnings = multiplier > 0 ? Math.floor(amount * multiplier) : 0;
        userData.wallet = userData.wallet - amount + winnings;
        userData.lastSlots = now;
        await setEconomyData(client, guildId, userId, userData);

        const color = multiplier > 3 ? '#FFD700' : multiplier > 0 ? '#57F287' : '#ED4245';
        const embed = createEmbed({ title: '🎰 Slot Machine', color: multiplier > 0 ? 'success' : 'error' })
            .setDescription(`${reels}\n\n${resultMsg}`)
            .addFields(
                { name: '💰 Bet', value: `BB ${amount.toLocaleString()}`, inline: true },
                { name: multiplier > 0 ? '🏆 Won' : '💸 Lost', value: `BB ${multiplier > 0 ? winnings.toLocaleString() : amount.toLocaleString()}`, inline: true },
                { name: '👛 Wallet', value: `BB ${userData.wallet.toLocaleString()}`, inline: true }
            );

        await InteractionHelper.safeEditReply(interaction, { embeds: [embed] });
    }, { command: 'slots' })
};
