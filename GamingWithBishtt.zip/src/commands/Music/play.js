import { SlashCommandBuilder } from 'discord.js';
import { handlePlayCommand } from '../../music.js';

export default {
    data: new SlashCommandBuilder()
        .setName('play')
        .setDescription('Play a song or playlist from YouTube, Spotify, and more')
        .addStringOption(opt =>
            opt.setName('query')
               .setDescription('Song name, URL, or playlist link')
               .setRequired(true)),
    async execute(interaction) {
        await handlePlayCommand(interaction);
    }
};
