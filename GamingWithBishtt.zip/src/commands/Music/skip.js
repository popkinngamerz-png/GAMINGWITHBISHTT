import { SlashCommandBuilder } from 'discord.js';
import { handleSkipCommand } from '../../music.js';

export default {
    data: new SlashCommandBuilder()
        .setName('skip')
        .setDescription('Skip the current track'),
    async execute(interaction) {
        await handleSkipCommand(interaction);
    }
};
