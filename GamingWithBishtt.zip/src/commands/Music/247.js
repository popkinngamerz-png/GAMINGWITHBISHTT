import { SlashCommandBuilder } from 'discord.js';
import { handle247Command } from '../../music.js';

export default {
    data: new SlashCommandBuilder()
        .setName('24-7')
        .setDescription('Toggle 24/7 mode (bot stays in VC permanently)'),
    async execute(interaction) {
        await handle247Command(interaction);
    }
};
