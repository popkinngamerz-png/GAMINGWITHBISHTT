import { SlashCommandBuilder } from 'discord.js';
import { handleStopCommand } from '../../music.js';

export default {
    data: new SlashCommandBuilder()
        .setName('stop')
        .setDescription('Stop music and clear the queue'),
    async execute(interaction) {
        await handleStopCommand(interaction);
    }
};
