import { SlashCommandBuilder } from 'discord.js';
import { handleAutoplayCommand } from '../../music.js';

export default {
    data: new SlashCommandBuilder()
        .setName('autoplay')
        .setDescription('Toggle autoplay (auto-queue related songs when queue ends)'),
    async execute(interaction) {
        await handleAutoplayCommand(interaction);
    }
};
