import { SlashCommandBuilder } from 'discord.js';
import { handleQueueCommand } from '../../music.js';

export default {
    data: new SlashCommandBuilder()
        .setName('queue')
        .setDescription('View the current music queue')
        .addIntegerOption(opt =>
            opt.setName('page')
               .setDescription('Page number')
               .setRequired(false)),
    async execute(interaction) {
        await handleQueueCommand(interaction);
    }
};
