import { SlashCommandBuilder } from 'discord.js';
import { handleNodeCommand } from '../../music.js';

export default {
    data: new SlashCommandBuilder()
        .setName('node')
        .setDescription('View Lavalink node status'),
    async execute(interaction) {
        await handleNodeCommand(interaction);
    }
};
