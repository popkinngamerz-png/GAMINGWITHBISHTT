import { SlashCommandBuilder } from 'discord.js';
import { handleVolumeCommand } from '../../music.js';

export default {
    data: new SlashCommandBuilder()
        .setName('volume')
        .setDescription('Set or view the music volume (0-100)')
        .addIntegerOption(opt =>
            opt.setName('level')
               .setDescription('Volume level (0-100)')
               .setRequired(false)
               .setMinValue(0)
               .setMaxValue(100)),
    async execute(interaction) {
        await handleVolumeCommand(interaction);
    }
};
