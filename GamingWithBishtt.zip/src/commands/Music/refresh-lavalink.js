import { SlashCommandBuilder } from 'discord.js';
import { handleRefreshLavalinkCommand } from '../../music.js';

export default {
    data: new SlashCommandBuilder()
        .setName('refresh-lavalink')
        .setDescription('Reconnect to offline Lavalink nodes'),
    async execute(interaction) {
        await handleRefreshLavalinkCommand(interaction);
    }
};
