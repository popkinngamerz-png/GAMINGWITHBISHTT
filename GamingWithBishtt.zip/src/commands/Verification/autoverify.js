export { default } from './modules/autoVerify.js';
