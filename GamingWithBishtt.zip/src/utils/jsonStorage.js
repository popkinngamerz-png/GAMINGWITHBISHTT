// ─────────────────────────────────────────────────────────────────────────────
// jsonStorage.js — Persistent file-based storage for GamingWithBishtt
//
// Saves all bot data to  data/globaldata.json  in the project root.
// Identical API to MemoryStorage so DatabaseWrapper can swap it in with zero
// changes to the rest of the codebase.
//
// Features:
//  • All data survives bot restarts
//  • Writes are batched (debounced 500 ms) to avoid hammering the disk
//  • Atomic writes (write to .tmp first, then rename) so a crash mid-write
//    never corrupts the file
//  • TTL (expiry) support — same as MemoryStorage
// ─────────────────────────────────────────────────────────────────────────────

import fs   from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { logger } from './logger.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR  = path.join(__dirname, '../../data');
const DATA_FILE = path.join(DATA_DIR, 'globaldata.json');
const TMP_FILE  = DATA_FILE + '.tmp';

// How long (ms) to wait before flushing a batch of writes to disk.
// 500 ms means at most 2 disk writes per second under heavy load.
const DEBOUNCE_MS = 500;

class JsonStorage {
    constructor() {
        // { [key]: { value: any, expiresAt: number|null } }
        this._store = {};
        this._dirty = false;
        this._flushTimer = null;
        this._loaded = false;
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    /** Call once at startup before any get/set. */
    async load() {
        if (this._loaded) return;

        // Ensure the data directory exists
        if (!fs.existsSync(DATA_DIR)) {
            fs.mkdirSync(DATA_DIR, { recursive: true });
            logger.info('[JsonStorage] Created data/ directory');
        }

        if (fs.existsSync(DATA_FILE)) {
            try {
                const raw = fs.readFileSync(DATA_FILE, 'utf8');
                this._store = JSON.parse(raw);
                const keyCount = Object.keys(this._store).length;
                logger.info(`[JsonStorage] ✅ Loaded ${keyCount} keys from globaldata.json`);
            } catch (err) {
                logger.warn(`[JsonStorage] ⚠️  Could not parse globaldata.json (${err.message}) — starting fresh`);
                this._store = {};
            }
        } else {
            logger.info('[JsonStorage] No existing globaldata.json — starting with empty store');
            this._store = {};
        }

        this._loaded = true;

        // Purge expired keys on boot
        const now = Date.now();
        let purged = 0;
        for (const key of Object.keys(this._store)) {
            const entry = this._store[key];
            if (entry && entry.expiresAt !== null && entry.expiresAt < now) {
                delete this._store[key];
                purged++;
            }
        }
        if (purged > 0) {
            logger.info(`[JsonStorage] Purged ${purged} expired keys on startup`);
            this._scheduleSave();
        }
    }

    // ── Internal helpers ──────────────────────────────────────────────────────

    _scheduleSave() {
        this._dirty = true;
        if (this._flushTimer) return;           // already queued
        this._flushTimer = setTimeout(() => {
            this._flushTimer = null;
            this._flush();
        }, DEBOUNCE_MS);
    }

    _flush() {
        if (!this._dirty) return;
        try {
            const json = JSON.stringify(this._store, null, 2);
            fs.writeFileSync(TMP_FILE, json, 'utf8');
            fs.renameSync(TMP_FILE, DATA_FILE);
            this._dirty = false;
        } catch (err) {
            logger.error('[JsonStorage] Failed to save globaldata.json:', err.message);
        }
    }

    /** Force an immediate synchronous flush (call on SIGTERM/SIGINT). */
    flushSync() {
        if (this._flushTimer) {
            clearTimeout(this._flushTimer);
            this._flushTimer = null;
        }
        this._flush();
    }

    _isExpired(entry) {
        return entry.expiresAt !== null && entry.expiresAt < Date.now();
    }

    // ── Public API (mirrors MemoryStorage exactly) ────────────────────────────

    async get(key, defaultValue = null) {
        const entry = this._store[key];
        if (entry === undefined) return defaultValue;
        if (this._isExpired(entry)) {
            delete this._store[key];
            this._scheduleSave();
            return defaultValue;
        }
        return entry.value ?? defaultValue;
    }

    async set(key, value, ttl = null) {
        const expiresAt = (ttl && ttl > 0) ? Date.now() + ttl * 1000 : null;
        this._store[key] = { value, expiresAt };
        this._scheduleSave();
        return true;
    }

    async delete(key) {
        if (key in this._store) {
            delete this._store[key];
            this._scheduleSave();
        }
        return true;
    }

    async list(prefix) {
        const now = Date.now();
        const keys = [];
        for (const key of Object.keys(this._store)) {
            if (!key.startsWith(prefix)) continue;
            const entry = this._store[key];
            if (entry.expiresAt !== null && entry.expiresAt < now) {
                delete this._store[key];
                this._scheduleSave();
                continue;
            }
            keys.push(key);
        }
        return keys;
    }

    async exists(key) {
        const entry = this._store[key];
        if (entry === undefined) return false;
        if (this._isExpired(entry)) {
            delete this._store[key];
            this._scheduleSave();
            return false;
        }
        return true;
    }

    async increment(key, amount = 1) {
        const current = await this.get(key, 0);
        const next = current + amount;
        await this.set(key, next);
        return next;
    }

    async decrement(key, amount = 1) {
        const current = await this.get(key, 0);
        const next = current - amount;
        await this.set(key, next);
        return next;
    }

    async clear() {
        this._store = {};
        this._scheduleSave();
        return true;
    }

    /** Return how many keys are currently stored (useful for status checks). */
    get size() {
        return Object.keys(this._store).length;
    }
}

// Export a single shared instance
export const jsonStorage = new JsonStorage();
