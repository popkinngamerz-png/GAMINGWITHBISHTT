import { Events } from 'discord.js';
import { logger } from '../utils/logger.js';
import { getLevelingConfig, getUserLevelData } from '../services/leveling.js';
import { addXp } from '../services/xpSystem.js';
import { checkRateLimit } from '../utils/rateLimiter.js';
import { getEconomyData, setEconomyData, getMaxBankCapacity } from '../utils/economy.js';
import { createEmbed, successEmbed, errorEmbed } from '../utils/embeds.js';
import { formatDuration } from '../utils/helpers.js';
import { MUSIC_PREFIX_ALIASES, handleMusicPrefixCommand } from '../music.js';

// ─────────────────────────────────────────────────────────────
// CONFIG
// ─────────────────────────────────────────────────────────────
const PREFIX = process.env.BOT_PREFIX || '!';
const MESSAGE_XP_RATE_LIMIT_ATTEMPTS = 12;
const MESSAGE_XP_RATE_LIMIT_WINDOW_MS = 10000;

// ─────────────────────────────────────────────────────────────
// ECONOMY PREFIX ALIASES
// These let users run economy commands with the prefix
// ─────────────────────────────────────────────────────────────
const ECONOMY_CMDS = new Set([
    'balance', 'bal',
    'daily',
    'weekly',
    'work',
    'beg',
    'flip', 'coinflip', 'cf',
    'slots',
    'deposit', 'dep',
    'withdraw', 'with',
    'pay', 'give',
    'rob',
    'gamble', 'bet',
    'profile', 'prof',
    'crime',
    'mine',
    'fish',
    'leaderboard', 'lb', 'top',
    'inventory', 'inv',
    'shop',
    'buy',
]);

// Command aliases → canonical name
const ALIAS_MAP = {
    bal: 'balance',
    coinflip: 'flip',
    cf: 'flip',
    give: 'pay',
    bet: 'gamble',
    prof: 'profile',
    dep: 'deposit',
    with: 'withdraw',
    lb: 'leaderboard',
    top: 'leaderboard',
    inv: 'inventory',
};

// ─────────────────────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────────────────────
function bbFmt(n) { return `BB ${Number(n).toLocaleString()}`; }

async function sendReply(message, embedOrContent) {
    try {
        if (typeof embedOrContent === 'string') {
            return await message.reply({ content: embedOrContent });
        }
        return await message.reply({ embeds: [embedOrContent] });
    } catch {
        // ignore send errors
    }
}

// ─────────────────────────────────────────────────────────────
// BUILT-IN PREFIX ECONOMY HANDLERS
// (fast inline versions — no interaction API needed)
// ─────────────────────────────────────────────────────────────

async function cmd_balance(message, args, client) {
    const target = message.mentions.users.first() || message.author;
    if (target.bot) return sendReply(message, '❌ Bots have no balance.');
    const data = await getEconomyData(client, message.guild.id, target.id);
    const maxBank = getMaxBankCapacity(data);
    return sendReply(message, createEmbed({ title: `💰 ${target.username}'s Balance`, color: 'primary' })
        .addFields(
            { name: '💵 Wallet', value: bbFmt(data.wallet), inline: true },
            { name: '🏦 Bank', value: `${bbFmt(data.bank)} / ${bbFmt(maxBank)}`, inline: true },
            { name: '💎 Total', value: bbFmt(data.wallet + data.bank), inline: true }
        ));
}

async function cmd_daily(message, args, client) {
    const userId = message.author.id;
    const guildId = message.guild.id;
    const now = Date.now();
    const COOLDOWN = 24 * 60 * 60 * 1000;
    const AMOUNT = 500;
    const data = await getEconomyData(client, guildId, userId);
    if (now < (data.lastDaily || 0) + COOLDOWN) {
        const rem = (data.lastDaily || 0) + COOLDOWN - now;
        return sendReply(message, `⏳ Come back in **${formatDuration(rem)}** for your daily!`);
    }
    data.wallet = (data.wallet || 0) + AMOUNT;
    data.lastDaily = now;
    await setEconomyData(client, guildId, userId, data);
    return sendReply(message, successEmbed(`You claimed **${bbFmt(AMOUNT)}**! New wallet: **${bbFmt(data.wallet)}**`, '✅ Daily Claimed!'));
}

async function cmd_weekly(message, args, client) {
    const userId = message.author.id;
    const guildId = message.guild.id;
    const now = Date.now();
    const COOLDOWN = 7 * 24 * 60 * 60 * 1000;
    const AMOUNT = 5000;
    const data = await getEconomyData(client, guildId, userId);
    if (now < (data.lastWeekly || 0) + COOLDOWN) {
        const rem = (data.lastWeekly || 0) + COOLDOWN - now;
        return sendReply(message, `⏳ Come back in **${formatDuration(rem)}** for your weekly!`);
    }
    data.wallet = (data.wallet || 0) + AMOUNT;
    data.lastWeekly = now;
    await setEconomyData(client, guildId, userId, data);
    return sendReply(message, successEmbed(`You claimed **${bbFmt(AMOUNT)}**! New wallet: **${bbFmt(data.wallet)}**`, '✅ Weekly Claimed!'));
}

async function cmd_work(message, args, client) {
    const userId = message.author.id;
    const guildId = message.guild.id;
    const now = Date.now();
    const COOLDOWN = 30 * 60 * 1000;
    const JOBS = ['Software Developer','Barista','YouTuber','Discord Bot Dev','Cashier','Pizza Delivery','Gamer','Streamer','Miner'];
    const data = await getEconomyData(client, guildId, userId);
    if (now < (data.lastWork || 0) + COOLDOWN) {
        const rem = (data.lastWork || 0) + COOLDOWN - now;
        return sendReply(message, `⏳ Rest up! You can work again in **${formatDuration(rem)}**.`);
    }
    const earned = Math.floor(Math.random() * 401) + 100;
    const job = JOBS[Math.floor(Math.random() * JOBS.length)];
    data.wallet = (data.wallet || 0) + earned;
    data.lastWork = now;
    await setEconomyData(client, guildId, userId, data);
    return sendReply(message, successEmbed(`You worked as a **${job}** and earned **${bbFmt(earned)}**!\nWallet: **${bbFmt(data.wallet)}**`, '💼 Work Complete!'));
}

async function cmd_flip(message, args, client) {
    const userId = message.author.id;
    const guildId = message.guild.id;
    const now = Date.now();
    const amtArg = args[0];
    const choiceArg = (args[1] || '').toLowerCase();
    if (!amtArg || isNaN(parseInt(amtArg))) return sendReply(message, `❌ Usage: \`${PREFIX}flip <amount> <heads/tails>\``);
    if (!['heads','tails','h','t'].includes(choiceArg)) return sendReply(message, `❌ Choose \`heads\` or \`tails\`.`);
    const amount = parseInt(amtArg);
    const choice = choiceArg.startsWith('h') ? 'heads' : 'tails';
    const data = await getEconomyData(client, guildId, userId);
    if (amount > data.wallet) return sendReply(message, `❌ You only have **${bbFmt(data.wallet)}**!`);
    if (now < (data.lastFlip || 0) + 30000) return sendReply(message, `⏳ Wait before flipping again!`);
    const result = Math.random() < 0.5 ? 'heads' : 'tails';
    const won = result === choice;
    data.wallet = won ? data.wallet + amount : data.wallet - amount;
    data.lastFlip = now;
    await setEconomyData(client, guildId, userId, data);
    const emoji = result === 'heads' ? '🪙' : '🌑';
    return sendReply(message, won
        ? successEmbed(`${emoji} **${result.toUpperCase()}** — You won **${bbFmt(amount)}**! Wallet: **${bbFmt(data.wallet)}**`, '🪙 Coin Flip — WIN!')
        : errorEmbed(`${emoji} **${result.toUpperCase()}** — You lost **${bbFmt(amount)}**! Wallet: **${bbFmt(data.wallet)}**`).setTitle('🪙 Coin Flip — LOSS!'));
}

async function cmd_slots(message, args, client) {
    const userId = message.author.id;
    const guildId = message.guild.id;
    const now = Date.now();
    const amtArg = args[0];
    if (!amtArg || isNaN(parseInt(amtArg))) return sendReply(message, `❌ Usage: \`${PREFIX}slots <amount>\``);
    const amount = parseInt(amtArg);
    const SYMBOLS = ['🍒','🍋','🍊','🍇','⭐','💎','7️⃣'];
    const PAYOUTS = { '7️⃣': 10, '💎': 7, '⭐': 5, '🍇': 4, '🍊': 3, '🍋': 2, '🍒': 1.5 };
    const spin = () => { const w=[20,18,15,12,10,5,2]; let r=Math.random()*82; for(let i=0;i<SYMBOLS.length;i++){r-=w[i];if(r<=0)return SYMBOLS[i];} return SYMBOLS[0]; };
    const data = await getEconomyData(client, guildId, userId);
    if (amount > data.wallet) return sendReply(message, `❌ You only have **${bbFmt(data.wallet)}**!`);
    if (now < (data.lastSlots || 0) + 60000) return sendReply(message, `⏳ Wait before spinning again!`);
    const [s1,s2,s3] = [spin(),spin(),spin()];
    let mult = 0, msg = '';
    if (s1===s2 && s2===s3) { mult = PAYOUTS[s1]||2; msg=`🎰 **JACKPOT!** Triple ${s1}! Won **${mult}x**!`; }
    else if (s1===s2||s2===s3||s1===s3) { mult=1.5; msg=`✨ Two of a kind! Won **1.5x**!`; }
    else { msg=`💸 No match. Better luck next time!`; }
    const wins = mult>0?Math.floor(amount*mult):0;
    data.wallet = data.wallet - amount + wins;
    data.lastSlots = now;
    await setEconomyData(client, guildId, userId, data);
    return sendReply(message, createEmbed({ title: '🎰 Slot Machine', color: mult>0?'success':'error' })
        .setDescription(`[ ${s1} | ${s2} | ${s3} ]\n\n${msg}`)
        .addFields(
            { name: '💰 Bet', value: bbFmt(amount), inline: true },
            { name: mult>0?'🏆 Won':'💸 Lost', value: bbFmt(mult>0?wins:amount), inline: true },
            { name: '👛 Wallet', value: bbFmt(data.wallet), inline: true }
        ));
}

async function cmd_deposit(message, args, client) {
    const userId = message.author.id;
    const guildId = message.guild.id;
    const data = await getEconomyData(client, guildId, userId);
    const maxBank = getMaxBankCapacity(data);
    if (!args[0]) return sendReply(message, `❌ Usage: \`${PREFIX}deposit <amount|all>\``);
    const amt = args[0].toLowerCase() === 'all' ? data.wallet : parseInt(args[0]);
    if (isNaN(amt) || amt <= 0) return sendReply(message, '❌ Invalid amount.');
    if (data.wallet < amt) return sendReply(message, `❌ You only have **${bbFmt(data.wallet)}** in your wallet.`);
    if (data.bank >= maxBank) return sendReply(message, `❌ Your bank is full! (${bbFmt(data.bank)}/${bbFmt(maxBank)})`);
    const actual = Math.min(amt, maxBank - data.bank);
    data.wallet -= actual;
    data.bank += actual;
    await setEconomyData(client, guildId, userId, data);
    return sendReply(message, successEmbed(`Deposited **${bbFmt(actual)}**\nBank: **${bbFmt(data.bank)}/${bbFmt(maxBank)}**`, '🏦 Deposit Successful'));
}

async function cmd_withdraw(message, args, client) {
    const userId = message.author.id;
    const guildId = message.guild.id;
    const data = await getEconomyData(client, guildId, userId);
    if (!args[0]) return sendReply(message, `❌ Usage: \`${PREFIX}withdraw <amount|all>\``);
    const amt = args[0].toLowerCase() === 'all' ? data.bank : parseInt(args[0]);
    if (isNaN(amt) || amt <= 0) return sendReply(message, '❌ Invalid amount.');
    if (data.bank < amt) return sendReply(message, `❌ You only have **${bbFmt(data.bank)}** in your bank.`);
    data.bank -= amt;
    data.wallet += amt;
    await setEconomyData(client, guildId, userId, data);
    return sendReply(message, successEmbed(`Withdrew **${bbFmt(amt)}**\nWallet: **${bbFmt(data.wallet)}**`, '🏦 Withdrawal Successful'));
}

async function cmd_pay(message, args, client) {
    const userId = message.author.id;
    const guildId = message.guild.id;
    const target = message.mentions.users.first();
    const amt = parseInt(args[1] || args[0]);
    if (!target || isNaN(amt) || amt <= 0) return sendReply(message, `❌ Usage: \`${PREFIX}pay @user <amount>\``);
    if (target.id === userId) return sendReply(message, '❌ You cannot pay yourself.');
    if (target.bot) return sendReply(message, '❌ You cannot pay a bot.');
    const senderData = await getEconomyData(client, guildId, userId);
    if (senderData.wallet < amt) return sendReply(message, `❌ You only have **${bbFmt(senderData.wallet)}**.`);
    const receiverData = await getEconomyData(client, guildId, target.id);
    senderData.wallet -= amt;
    receiverData.wallet = (receiverData.wallet || 0) + amt;
    await setEconomyData(client, guildId, userId, senderData);
    await setEconomyData(client, guildId, target.id, receiverData);
    return sendReply(message, successEmbed(`**${message.author.username}** paid **${target.username}** → **${bbFmt(amt)}** 💸`, '✅ Payment Sent'));
}

async function cmd_profile(message, args, client) {
    const target = message.mentions.users.first() || message.author;
    if (target.bot) return sendReply(message, '❌ Bots have no profiles.');
    const data = await getEconomyData(client, message.guild.id, target.id);
    const maxBank = getMaxBankCapacity(data);
    return sendReply(message, createEmbed({ title: `🎮 ${target.username}'s Profile`, color: 'primary', thumbnail: target.displayAvatarURL() })
        .addFields(
            { name: '💵 Wallet', value: bbFmt(data.wallet), inline: true },
            { name: '🏦 Bank', value: `${bbFmt(data.bank)} / ${bbFmt(maxBank)}`, inline: true },
            { name: '💎 Net Worth', value: bbFmt(data.wallet + data.bank), inline: true },
            { name: '⭐ Level', value: `${data.level || 1}`, inline: true },
            { name: '🔥 Daily Streak', value: `${data.dailyStreak || 0} days`, inline: true }
        )
        .setFooter({ text: `GamingWithBishtt Economy` }));
}

async function cmd_help(message, args, client) {
    const p = PREFIX;
    return sendReply(message, createEmbed({ title: '📖 GamingWithBishtt — Prefix Commands', color: 'info' })
        .setDescription(`Prefix: **\`${p}\`** — All commands also work as **slash commands** (/command)\n\n` +
            `**💰 Economy**\n` +
            `\`${p}balance [@user]\` • \`${p}daily\` • \`${p}weekly\` • \`${p}work\`\n` +
            `\`${p}flip <amt> <h/t>\` • \`${p}slots <amt>\` • \`${p}gamble\` (slash only)\n` +
            `\`${p}deposit <amt|all>\` • \`${p}withdraw <amt|all>\` • \`${p}pay @user <amt>\`\n` +
            `\`${p}rob @user\` • \`${p}beg\` • \`${p}profile [@user]\` • \`${p}inventory\`\n\n` +
            `**🎵 Music**\n` +
            `\`${p}play <song>\` • \`${p}stop\` • \`${p}skip\` • \`${p}queue\` • \`${p}autoplay\`\n\n` +
            `**ℹ️ Info**\n` +
            `\`${p}help\` — This menu\n\n` +
            `*All features also available via slash commands — type \`/\` in chat!*`)
        .setFooter({ text: 'GamingWithBishtt by Popkinn_Editz' }));
}

// Map command names to handler functions (inline prefix handlers)
const PREFIX_HANDLERS = {
    balance: cmd_balance,
    daily: cmd_daily,
    weekly: cmd_weekly,
    work: cmd_work,
    flip: cmd_flip,
    slots: cmd_slots,
    deposit: cmd_deposit,
    withdraw: cmd_withdraw,
    pay: cmd_pay,
    profile: cmd_profile,
    help: cmd_help,
};

// ─────────────────────────────────────────────────────────────
// MAIN EVENT
// ─────────────────────────────────────────────────────────────
export default {
    name: Events.MessageCreate,
    async execute(message, client) {
        try {
            if (message.author.bot || !message.guild) return;

            // ── Prefix command handling ──────────────────────────────────────
            if (message.content.startsWith(PREFIX)) {
                const args = message.content.slice(PREFIX.length).trim().split(/\s+/);
                const rawCmd = args.shift().toLowerCase();
                const cmd = ALIAS_MAP[rawCmd] || rawCmd;

                // 1. Inline economy prefix handlers
                if (PREFIX_HANDLERS[cmd]) {
                    try {
                        await PREFIX_HANDLERS[cmd](message, args, client);
                    } catch (err) {
                        logger.error(`[PREFIX] Error in command ${cmd}:`, err);
                        await sendReply(message, `❌ An error occurred running \`${cmd}\`. Try the slash command version.`);
                    }
                    return;
                }

                // 2. Music prefix commands (from music.js MUSIC_PREFIX_ALIASES)
                for (const [musicCmd, aliases] of Object.entries(MUSIC_PREFIX_ALIASES)) {
                    if (aliases.includes(cmd)) {
                        try {
                            await handleMusicPrefixCommand(message, musicCmd, args);
                        } catch (err) {
                            logger.error(`[PREFIX] Music error in ${cmd}:`, err);
                            await sendReply(message, `❌ Music error. Make sure you're in a voice channel.`);
                        }
                        return;
                    }
                }

                // 3. Forward to slash command system via fake interaction (for remaining commands)
                if (client.commands && client.commands.has(cmd)) {
                    const slashCmd = client.commands.get(cmd);
                    logger.debug(`[PREFIX] Forwarding "${cmd}" to slash command handler`);
                    // These commands require a real interaction — inform user to use slash
                    await sendReply(message, `ℹ️ **\`/${cmd}\`** must be used as a slash command. Type \`/${cmd}\` in chat!`);
                    return;
                }
            }

            // ── XP / Leveling (always runs) ─────────────────────────────────
            await handleLeveling(message, client);

        } catch (error) {
            logger.error('Error in messageCreate event:', error);
        }
    }
};

// ─────────────────────────────────────────────────────────────
// LEVELING (unchanged from original)
// ─────────────────────────────────────────────────────────────
async function handleLeveling(message, client) {
    try {
        const rateLimitKey = `xp-event:${message.guild.id}:${message.author.id}`;
        const canProcess = await checkRateLimit(rateLimitKey, MESSAGE_XP_RATE_LIMIT_ATTEMPTS, MESSAGE_XP_RATE_LIMIT_WINDOW_MS);
        if (!canProcess) return;

        const levelingConfig = await getLevelingConfig(client, message.guild.id);
        if (!levelingConfig?.enabled) return;
        if (levelingConfig.ignoredChannels?.includes(message.channel.id)) return;

        if (levelingConfig.ignoredRoles?.length > 0) {
            const member = await message.guild.members.fetch(message.author.id).catch(() => null);
            if (member && member.roles.cache.some(role => levelingConfig.ignoredRoles.includes(role.id))) return;
        }

        if (levelingConfig.blacklistedUsers?.includes(message.author.id)) return;
        if (!message.content || message.content.trim().length === 0) return;

        const userData = await getUserLevelData(client, message.guild.id, message.author.id);
        const cooldownTime = levelingConfig.xpCooldown || 60;
        const now = Date.now();
        const timeSinceLastMessage = now - (userData.lastMessage || 0);
        if (timeSinceLastMessage < cooldownTime * 1000) return;

        const minXP = levelingConfig.xpRange?.min || levelingConfig.xpPerMessage?.min || 15;
        const maxXP = levelingConfig.xpRange?.max || levelingConfig.xpPerMessage?.max || 25;
        const safeMinXP = Math.max(1, minXP);
        const safeMaxXP = Math.max(safeMinXP, maxXP);
        let finalXP = Math.floor(Math.random() * (safeMaxXP - safeMinXP + 1)) + safeMinXP;
        if (levelingConfig.xpMultiplier && levelingConfig.xpMultiplier > 1) {
            finalXP = Math.floor(finalXP * levelingConfig.xpMultiplier);
        }

        const result = await addXp(client, message.guild, message.member, finalXP);
        if (result.success && result.leveledUp) {
            logger.info(`${message.author.tag} leveled up to level ${result.level} in ${message.guild.name}`);
        }
    } catch (error) {
        logger.error('Error handling leveling for message:', error);
    }
}
